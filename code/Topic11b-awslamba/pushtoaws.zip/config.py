airtable_config = {
    "apikey":"keyHvBdD1qvCodo2t",
    "baseURL":"https://api.airtable.com/v0/",
    "logtable":{
        "urlendpoint":"appZGRXgKTaRWDbO2/log"

    }
}