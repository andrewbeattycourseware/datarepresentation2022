airtable_config = {
    "apikey":"your key here",
    "baseURL":"https://api.airtable.com/v0/",
    "logtable":{
        "urlendpoint":"thetablecode/log"

    }
}